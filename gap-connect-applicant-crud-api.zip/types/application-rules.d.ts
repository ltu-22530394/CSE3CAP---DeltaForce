declare module "@/lib/application-rules.mjs" {
  export const APPLICATION_TYPES: readonly string[];
  export const REQUIRED_SUBMISSION_FIELDS: readonly string[];
  export function validateDraft(input: unknown): Record<string,string>;
  export function validateSubmission(input: unknown): Record<string,string>;
  export function canEdit(application: unknown, applicantId: string): boolean;
}
