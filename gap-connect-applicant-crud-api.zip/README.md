# GAP Connect

A capstone MVP for Greyhounds As Pets NSW. The app provides a friendly applicant journey and a secure staff workspace for reviewing applications, recording decisions, importing greyhound records, making manual assignments and reporting.

## Demo

The interactive web prototype runs from the repository root. Use **Applicant sign in** or **Staff sign in** on the landing page; development accounts do not require credentials. The prototype uses realistic in-memory demo data so every core workflow can be presented without infrastructure.

## Architecture

- `app/` — responsive React/TypeScript web prototype
- `backend/` — ASP.NET Core layered solution blueprint and domain model
- `docs/` — architecture, Confluence-ready project pages and Jira backlog
- `sample-data/` — validated greyhound CSV fixture
- `docker-compose.yml` — PostgreSQL and MailHog development services

Production implementation target: React + TypeScript, ASP.NET Core 8, EF Core, PostgreSQL, JWT applicant authentication, Microsoft Entra ID staff authentication, MailKit email, xUnit and Vitest.

## Core rules demonstrated

- No automated matching: staff select and assign greyhounds manually.
- Every status transition includes actor, timestamp and optional comment.
- Applicant data is separated from staff-only notes and audit data.
- One active assignment per application and per greyhound.
- CSV imports validate every row and return a clear summary.

## Local development

1. Install JavaScript dependencies with `pnpm install`.
2. Start the site with `pnpm dev`.
3. Optionally run PostgreSQL and MailHog with `docker compose up -d`.
4. Create `.env` from `.env.example`; never commit real secrets.

MailHog UI is available at `http://localhost:8025`; PostgreSQL uses port `5432`.

## Five sprint increments

1. Foundation, design system, solution structure, security and data model.
2. Applicant registration, profiles, drafts, submission and tracking.
3. Staff dashboard, review, notes, status decisions and history.
4. CSV import, greyhound records, manual assignment, notifications and reports.
5. Automated testing, accessibility, responsive QA, hardening and deployment.

See `docs/jira-backlog.md` for stories and `docs/confluence/` for handover documentation.
