CREATE TABLE `application_status_history` (
	`id` text PRIMARY KEY NOT NULL,
	`application_id` text NOT NULL,
	`applicant_id` text NOT NULL,
	`previous_status` text,
	`new_status` text NOT NULL,
	`changed_at` text NOT NULL,
	`comment` text
);
--> statement-breakpoint
CREATE INDEX `idx_application_history_application_time` ON `application_status_history` (`application_id`,`changed_at`);--> statement-breakpoint
CREATE TABLE `applications` (
	`id` text PRIMARY KEY NOT NULL,
	`applicant_id` text NOT NULL,
	`type` text NOT NULL,
	`status` text DEFAULT 'Draft' NOT NULL,
	`answers_json` text DEFAULT '{}' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`submitted_at` text
);
--> statement-breakpoint
CREATE INDEX `idx_applications_applicant_updated` ON `applications` (`applicant_id`,`updated_at`);