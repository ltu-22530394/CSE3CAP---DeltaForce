# Project Overview

**Project:** GAP Connect — Foster and Adoption Management System  
**Client:** Greyhounds As Pets, Greyhound Racing NSW  
**Team:** Four-student capstone team · five Agile sprints

## Purpose

GAP Connect replaces fragmented application handling with a secure applicant portal and staff workspace. Applicants can draft, submit and track foster/adoption applications. Staff can review, record decisions, import greyhounds, make manual assignments and report on operations.

## MVP success measures

- A public applicant can complete the full journey without staff assistance.
- Staff can locate, review and decide any submitted application.
- Every decision and sensitive staff action is traceable.
- CSV import reports actionable row errors.
- Assignment is deliberately manual and prevents double-booking.

## Scope boundaries

No matching algorithm, live Salesforce integration, automated greyhound selection, payment processing or public greyhound marketplace is included.

## Stakeholders

Applicants, foster carers, adopters, GAP assessors, placement staff, managers, client sponsor, capstone supervisors and the student development team.

## Delivery

See the Jira backlog for sprint allocation. Demonstrations should use the seeded applicant Sophie Bennett, application APP-1048 and greyhound Milo.
