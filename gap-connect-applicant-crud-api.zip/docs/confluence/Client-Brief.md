# Client Brief

## Problem

GAP needs a consistent, secure way to receive public applications and coordinate staff review and greyhound placement. The solution must reduce manual administration without replacing staff judgment.

## Required outcomes

Applicants authenticate with email/password, manage profiles, save drafts, submit and track applications, view outcomes and assigned dogs, and receive email updates. Staff authenticate through an Entra-ready design, review all applicant data, add private notes, manage status, import and filter greyhounds, assign manually, report and audit.

## Non-negotiable rules

1. No matching algorithm.
2. Only staff assign a greyhound.
3. Greyhounds originate from CSV.
4. No live Salesforce dependency.
5. Status history is append-only.
6. Sensitive applicant information is Staff-only outside its owner.

## Assumptions and decisions

PostgreSQL is the proposed store. Email uses an abstraction with MailHog locally. JWT serves applicants; Microsoft Entra ID is the production staff identity provider, with an explicit development handler when credentials are unavailable. Images are optional URLs from CSV.
