# Database Design

```mermaid
erDiagram
  USER ||--o| APPLICANT_PROFILE : has
  USER ||--o| STAFF_PROFILE : has
  APPLICANT_PROFILE ||--o{ APPLICATION : submits
  APPLICATION ||--o{ APPLICATION_ANSWER : contains
  APPLICATION ||--o{ STATUS_HISTORY : records
  APPLICATION ||--o{ STAFF_NOTE : receives
  APPLICATION ||--o| GREYHOUND_ASSIGNMENT : active_assignment
  GREYHOUND ||--o| GREYHOUND_ASSIGNMENT : active_assignment
  USER ||--o{ EMAIL_NOTIFICATION : receives
  USER ||--o{ AUDIT_LOG : performs
```

## Constraints

- `User.NormalizedEmail` unique; one applicant/staff profile per user.
- `Greyhound.ExternalId` unique and used as CSV upsert key.
- `ApplicationAnswer (ApplicationId, QuestionKey)` unique.
- Status history is append-only and ordered by `(ChangedAt, Id)`.
- Partial unique indexes on `GreyhoundAssignment.ApplicationId` and `.GreyhoundId` where `EndedAt IS NULL` enforce one active assignment.
- Approved status and available greyhound rules are checked in the assignment transaction.
- Concurrency tokens protect status and availability changes.

## Sensitive data

Applicant contact, household and lifestyle answers are restricted to the owner and Staff. Staff notes, medical/behaviour notes and audit metadata are Staff-only. Password hashes and reset-token hashes are never returned. Retention and deletion periods require client confirmation before production.

## Indexes

Normalized email, application applicant/status/submitted date/postcode, status-history application/time, greyhound external ID/availability/status, assignment active keys and audit actor/time/entity.

## Seed data

Development seeds include staff Jordan Miller; applicant Sophie Bennett; adoption application APP-1048 with history; and sample greyhounds Milo, Daisy, Archie and Luna. Seed credentials must never run outside Development.
