# Architecture

## Logical view

```mermaid
flowchart LR
    A["Applicant browser"] --> W["React web application"]
    S["Staff browser"] --> W
    W --> API["ASP.NET Core API"]
    API --> AUTH["JWT / Microsoft Entra ID"]
    API --> DB[("PostgreSQL")]
    API --> OUT["Notification outbox"]
    OUT --> SMTP["SMTP / MailHog"]
    CSV["Greyhound CSV"] --> API
```

## Backend layers

- **API:** HTTP contracts, authentication, authorization and problem responses.
- **Application:** use cases, validation, transactions and service interfaces.
- **Domain:** entities, status rules and invariants without infrastructure dependencies.
- **Infrastructure:** EF Core, PostgreSQL, CSV parser, MailKit and Entra adapters.
- **Tests:** domain units, service integration tests and authorization/API tests.

Dependencies point inward: API and Infrastructure depend on Application/Domain; Domain depends on neither.

## Authentication

Applicant login verifies an adaptive password hash and issues a short-lived JWT containing subject and Applicant role. Staff use Entra authorization code flow; the API validates issuer/audience and maps approved tenant identities to Staff profiles. Development login is compiled/configured only for Development.

## Authorization

Every application query includes either `ApplicantId == current applicant` or the Staff policy. Separate response DTOs ensure internal notes, audit metadata, medical notes and private staff comments cannot accidentally reach applicant responses.

## Key sequences

Submission validates the complete form, updates Draft to Submitted, appends status history, writes audit/outbox entries and commits. Assignment locks/checks the application and greyhound, creates one active assignment, sets dog unavailable and application to Greyhound Assigned, appends history/audit/outbox, then commits.

## API surface

`/api/auth/*`, `/api/profile`, `/api/applications`, `/api/staff/applications`, `/api/staff/greyhounds`, `/api/staff/imports`, `/api/staff/assignments`, `/api/staff/reports`, `/api/staff/audit`. Swagger documents contracts and authorization.
