# Functional Requirements

## Applicant

- Register, sign in/out, reset/change password and update own profile.
- Create Foster or Adopt applications containing the specified personal, household, lifestyle and agreement fields.
- Save partial drafts; submit only when fully valid; withdraw where allowed.
- List and open own applications; view status timeline, outcome and assigned dog.
- Receive registration, submitted, approved, rejected, more-information and assigned emails.

## Staff

- Sign in through Entra ID or the development-only handler.
- View dashboard counts, status and submission charts, recent applications and action queue.
- Search/filter applications by type, status, date, name and postcode.
- View complete applications and profiles; add private notes; change status; approve or reject with reason.
- Import required CSV columns and receive total/success/failure/error summary.
- Search/filter greyhounds by availability, age, sex and adoption status.
- Manually assign one available dog to one approved application.
- View status history and audit events; export safe CSV reports.

## Status workflow

Draft → Submitted → Under Review → More Information Required/Approved/Rejected. Approved → Greyhound Assigned → Completed. Submitted and later records may be Withdrawn subject to policy. Every transition records previous/new state, actor, UTC time and optional comment.

## Error behaviour

Validation errors identify fields; authorization failures reveal no protected data; conflicts explain stale status or unavailable dog; retryable service failures preserve user input; empty and loading states provide next actions.
