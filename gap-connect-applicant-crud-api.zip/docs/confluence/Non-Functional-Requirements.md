# Non-Functional Requirements

## Security and privacy

Use adaptive password hashing, short-lived signed JWTs, secure reset tokens, role policies, record ownership filters, server validation, parameterized ORM queries, output encoding and safe problem details. Audit profile reads, exports, notes, decisions, imports and assignments. Never log passwords, tokens, medical notes or full application bodies.

## Accessibility and usability

Target WCAG 2.2 AA. All workflows must support keyboard and touch, visible focus, programmatic labels, error summaries, adequate contrast, 200% zoom and reduced motion. Primary layouts support modern desktop and tablet widths.

## Reliability and integrity

Status changes, audit records and notification outbox entries are one transaction. Assignment uses database constraints/transactions to prevent concurrent double assignment. CSV imports are idempotent by ExternalId. Timestamps are UTC and displayed in Australia/Sydney.

## Performance

Target p95 API reads under 500 ms and writes under 1 s under expected capstone load. Paginate staff lists; limit uploads to 10 MB; index normalized email, status, submitted time, postcode, ExternalId and availability.

## Maintainability and operability

Use cohesive layers, dependency injection, migrations, structured logs, health checks, environment configuration and automated tests. Student developers should be able to explain each layer and trace a workflow end to end.

## Compatibility and recovery

Support current Chrome, Edge, Safari and Firefox. Back up PostgreSQL daily in production; test restore before handover; document migration rollback and deployment rollback.
