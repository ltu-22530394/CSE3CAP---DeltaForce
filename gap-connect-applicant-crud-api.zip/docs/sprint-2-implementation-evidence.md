# Sprint 2 implementation evidence

## Wireframe and API review

- Reviewed Song's landing, authentication, applicant, staff, greyhound-management, and reporting wireframes before implementation.
- Preserved the existing visual language and five-step applicant flow.
- Reviewed DEL-43 (Authentication API). It remains in progress without a published contract, acceptance criteria, subtasks, or linked development evidence.

## Delivered

- Applicant application endpoints: list/create, read/update/delete owned drafts, and submit.
- Durable D1 storage for applications and status history.
- Server-side draft and submission validation.
- Ownership checks on every application operation.
- Applicant UI connected to saved records, including save/resume/submit, loading, and error states.
- Automated tests for draft validation, submission validation, and edit ownership.

## Known constraints and risks

- Production identity integration is blocked by DEL-43. The hosted capstone demo uses an explicit demo-applicant header; platform-authenticated users use their authenticated user ID.
- Staff review, assignment, CSV import, reporting, and audit screens still use demonstration data and need separate backend stories.
- The wireframe review record should be closed with reviewer, decision, and dated feedback.

## Next actions

1. Agree the DEL-43 JWT/session contract and replace the demo identity fallback.
2. Add integration tests against a deployed D1 environment.
3. Implement staff application review/status APIs and role authorization.
4. Connect greyhound import, manual assignment, reports, and audit history to persistence.
