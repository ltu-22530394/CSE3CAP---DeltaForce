# Jira Backlog

Priority: P0 critical, P1 high, P2 medium. Estimates use Fibonacci story points.

## Epic: Project Foundation

### GAP-1 — Establish the solution
**Story:** As a developer, I want a layered monorepo, so that the team can work independently without coupling concerns.  
**Description:** Create web, API, domain, application, infrastructure, tests, Docker and documentation surfaces.  
**Acceptance criteria:** The site and API build; local PostgreSQL and MailHog start; configuration comes from environment variables; no secrets are committed.  
**Dependencies:** None · **Priority:** P0 · **Points:** 5 · **Sprint:** 1

### GAP-2 — Define the data model
**Story:** As a developer, I want a versioned relational schema, so that application and assignment data remains consistent.  
**Acceptance criteria:** All brief entities exist; relationships and unique active-assignment constraints are documented; migrations and representative seeds are supplied.  
**Dependencies:** GAP-1 · **Priority:** P0 · **Points:** 8 · **Sprint:** 1

## Epic: Authentication

### GAP-3 — Applicant account access
**Story:** As an applicant, I want to register, sign in and reset my password, so that I can securely manage my applications.  
**Acceptance criteria:** Email is unique and normalized; passwords are hashed; short-lived JWTs are issued; reset tokens expire and are single use; unsafe errors reveal no account existence.  
**Dependencies:** GAP-1, GAP-2 · **Priority:** P0 · **Points:** 8 · **Sprint:** 2

### GAP-4 — Staff identity and authorization
**Story:** As GAP staff, I want to sign in with Microsoft Entra ID, so that staff access follows organisational identity controls.  
**Acceptance criteria:** Entra configuration is environment-driven; a development-only login is available; API and web routes require the Staff role; applicant access receives 403.  
**Dependencies:** GAP-1 · **Priority:** P0 · **Points:** 8 · **Sprint:** 3

## Epic: Applicant Portal

### GAP-5 — Maintain my profile
**Story:** As an applicant, I want to view and edit my profile, so that GAP has current contact information.  
**Acceptance criteria:** Required fields are validated on client and server; postcode and phone rules are clear; applicants can read and update only their own profile.  
**Dependencies:** GAP-3 · **Priority:** P1 · **Points:** 5 · **Sprint:** 2

### GAP-6 — Complete an application
**Story:** As an applicant, I want to complete a guided foster or adoption form, so that I can tell GAP about my home and lifestyle.  
**Acceptance criteria:** All required brief fields are present; conditional landlord/pet/child questions work; accessible errors identify each problem; type is Foster or Adopt.  
**Dependencies:** GAP-3, GAP-5 · **Priority:** P0 · **Points:** 13 · **Sprint:** 2

### GAP-7 — Save and submit
**Story:** As an applicant, I want to save a draft and submit it later, so that I can complete the form at my own pace.  
**Acceptance criteria:** Drafts allow partial data; submission performs full server validation; submission time and status history are recorded atomically; a confirmation email is queued.  
**Dependencies:** GAP-6, GAP-17 · **Priority:** P0 · **Points:** 8 · **Sprint:** 2

## Epic: Application Management

### GAP-8 — Track my application
**Story:** As an applicant, I want a status timeline and outcome, so that I know what is happening.  
**Acceptance criteria:** Current and historical statuses are ordered by time; staff-only comments and notes never appear; rejection reason appears when appropriate; assigned greyhound appears after assignment.  
**Dependencies:** GAP-7 · **Priority:** P1 · **Points:** 5 · **Sprint:** 2

### GAP-9 — Govern status transitions
**Story:** As staff, I want every status change recorded, so that decisions are traceable.  
**Acceptance criteria:** Previous/new status, actor, UTC timestamp and optional comment are recorded; invalid transitions return 409; approve/reject queue the correct email.  
**Dependencies:** GAP-2, GAP-4 · **Priority:** P0 · **Points:** 8 · **Sprint:** 3

## Epic: Staff Portal

### GAP-10 — Review the queue
**Story:** As staff, I want to search and filter applications, so that I can prioritise work.  
**Acceptance criteria:** Filters cover type, status, date, applicant name and postcode; filters combine; results paginate; loading, empty and failure states are accessible.  
**Dependencies:** GAP-4, GAP-7 · **Priority:** P0 · **Points:** 8 · **Sprint:** 3

### GAP-11 — Review an application
**Story:** As staff, I want to see complete applicant details and private notes, so that I can make an informed decision.  
**Acceptance criteria:** Sensitive fields require Staff authorization; notes show author/time and are never returned to applicant endpoints; access and updates create audit events.  
**Dependencies:** GAP-9, GAP-10 · **Priority:** P0 · **Points:** 8 · **Sprint:** 3

### GAP-12 — Decide an application
**Story:** As staff, I want to approve or reject an application, so that the applicant receives a clear outcome.  
**Acceptance criteria:** Approval requires confirmation; rejection requires a reason; transitions and audit records are atomic; professional email is queued.  
**Dependencies:** GAP-9, GAP-11 · **Priority:** P0 · **Points:** 5 · **Sprint:** 3

## Epic: Greyhound Management

### GAP-13 — Import CSV records
**Story:** As staff, I want to import greyhounds from CSV, so that Salesforce exports can populate the system without live integration.  
**Acceptance criteria:** All expected fields are supported; duplicate ExternalId updates safely; total/success/failure counts and row errors are returned; no partial silent failures occur.  
**Dependencies:** GAP-2, GAP-4 · **Priority:** P0 · **Points:** 8 · **Sprint:** 4

### GAP-14 — Browse greyhounds
**Story:** As staff, I want to filter greyhounds, so that I can inspect suitable available records.  
**Acceptance criteria:** Availability, age, sex and adoption-status filters combine; medical and behaviour notes are Staff-only; external IDs are searchable.  
**Dependencies:** GAP-13 · **Priority:** P1 · **Points:** 5 · **Sprint:** 4

### GAP-15 — Assign manually
**Story:** As staff, I want to manually assign an available greyhound to an approved applicant, so that professional judgment determines every placement.  
**Acceptance criteria:** There is no recommendation or matching algorithm; only approved applications and available dogs can be selected; one active assignment per application and dog is enforced transactionally; history, audit and email records are created.  
**Dependencies:** GAP-12, GAP-14, GAP-17 · **Priority:** P0 · **Points:** 8 · **Sprint:** 4

## Epic: Notifications

### GAP-16 — Register notification templates
**Story:** As an applicant, I want clear account emails, so that I understand security events.  
**Acceptance criteria:** Registration and password reset templates are branded, responsive and include text fallbacks; links use configured base URL.  
**Dependencies:** GAP-3 · **Priority:** P1 · **Points:** 3 · **Sprint:** 2

### GAP-17 — Send workflow notifications
**Story:** As an applicant, I want email updates, so that I do not need to repeatedly check the portal.  
**Acceptance criteria:** Submitted, approved, rejected, more-information and assigned templates exist; delivery is queued after the transaction; retries and failures are recorded; MailHog supports development testing.  
**Dependencies:** GAP-1 · **Priority:** P0 · **Points:** 5 · **Sprint:** 4

## Epic: Reporting

### GAP-18 — Dashboard statistics
**Story:** As staff, I want summary statistics and charts, so that I can monitor demand and workload.  
**Acceptance criteria:** Required counts, recent items, action queue, status distribution and submissions over time use server-calculated data; date zone is documented.  
**Dependencies:** GAP-10, GAP-14 · **Priority:** P1 · **Points:** 8 · **Sprint:** 4

### GAP-19 — Export reports
**Story:** As staff, I want filtered CSV exports, so that I can share operational reports.  
**Acceptance criteria:** Current filters apply; spreadsheet-formula injection is escaped; UTF-8 headings are clear; export access is audited.  
**Dependencies:** GAP-18 · **Priority:** P2 · **Points:** 5 · **Sprint:** 4

## Epic: Testing

### GAP-20 — Automated assurance
**Story:** As a developer, I want automated tests, so that the team can change the system safely.  
**Acceptance criteria:** xUnit covers transitions, ownership, assignment uniqueness and import validation; integration tests cover 401/403/404; Vitest covers form rules and workflows; CI blocks regressions.  
**Dependencies:** GAP-3–GAP-19 · **Priority:** P0 · **Points:** 13 · **Sprint:** 5

### GAP-21 — Accessibility and responsive QA
**Story:** As a user, I want an accessible tablet-friendly interface, so that I can complete tasks comfortably.  
**Acceptance criteria:** WCAG 2.2 AA checks pass for keyboard, focus, labels, errors, contrast and reflow; desktop/tablet acceptance tests are recorded.  
**Dependencies:** GAP-6, GAP-10 · **Priority:** P1 · **Points:** 8 · **Sprint:** 5

## Epic: Deployment

### GAP-22 — Deploy safely
**Story:** As the team, we want repeatable deployment, so that the final system can be demonstrated reliably.  
**Acceptance criteria:** Production configuration, HTTPS, migrations, health checks, backup/restore and rollback are documented; secrets use platform storage; logs exclude personal data.  
**Dependencies:** GAP-20 · **Priority:** P0 · **Points:** 8 · **Sprint:** 5

## Epic: Documentation

### GAP-23 — Handover pack
**Story:** As the client and assessment panel, we want clear documentation, so that we can understand, evaluate and continue the system.  
**Acceptance criteria:** Overview, brief, functional/non-functional requirements, architecture, database design, API/auth setup, runbook and five-sprint evidence are current and reviewed.  
**Dependencies:** All epics · **Priority:** P1 · **Points:** 8 · **Sprint:** 1–5

## Technical task register

| Task | Epic | Points | Sprint |
|---|---|---:|---:|
| Configure EF Core migrations, indexes and seeds | Foundation | 5 | 1 |
| Add Zod and FluentValidation schemas | Applicant Portal | 5 | 2 |
| Implement ownership-aware query filters | Authentication | 5 | 2 |
| Add Entra configuration and development auth handler | Authentication | 5 | 3 |
| Add transactional outbox for email | Notifications | 5 | 4 |
| Add CSV formula-injection protection | Reporting | 3 | 4 |
| Add CI build, test and dependency scan | Testing | 5 | 5 |
| Complete threat model and privacy review | Deployment | 5 | 5 |
