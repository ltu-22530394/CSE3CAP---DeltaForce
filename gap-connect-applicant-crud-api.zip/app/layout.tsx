import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "GAP Connect — Foster & Adoption",
  description: "Apply to foster or adopt a greyhound, and track your journey with Greyhounds As Pets NSW.",
  icons: { icon: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
