import { NextResponse } from "next/server";
import { getApplication, submitApplication } from "@/lib/application-store";
import { getApplicantId } from "@/lib/applicant-identity";
import { validateSubmission } from "@/lib/application-rules.mjs";

export const dynamic="force-dynamic";
type Context={params:Promise<{id:string}>};

export async function POST(request:Request,{params}:Context){
  const applicantId=await getApplicantId(request); if(!applicantId)return NextResponse.json({error:"Authentication required."},{status:401});
  const {id}=await params; const current=await getApplication(id,applicantId);
  if(!current)return NextResponse.json({error:"Application not found."},{status:404});
  if(current.status!=="Draft")return NextResponse.json({error:"Only drafts can be submitted."},{status:409});
  const errors=validateSubmission(current);
  if(Object.keys(errors).length)return NextResponse.json({error:"Complete all required fields before submitting.",errors},{status:400});
  return NextResponse.json({application:await submitApplication(id,applicantId)});
}
