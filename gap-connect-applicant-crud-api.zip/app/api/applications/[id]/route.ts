import { NextResponse } from "next/server";
import { deleteApplication, getApplication, updateApplication } from "@/lib/application-store";
import { getApplicantId } from "@/lib/applicant-identity";
import { validateDraft } from "@/lib/application-rules.mjs";

export const dynamic = "force-dynamic";
type Context={params:Promise<{id:string}>};

export async function GET(request:Request,{params}:Context){
  const applicantId=await getApplicantId(request); if(!applicantId)return NextResponse.json({error:"Authentication required."},{status:401});
  const {id}=await params; const application=await getApplication(id,applicantId);
  return application?NextResponse.json({application}):NextResponse.json({error:"Application not found."},{status:404});
}

export async function PUT(request:Request,{params}:Context){
  const applicantId=await getApplicantId(request); if(!applicantId)return NextResponse.json({error:"Authentication required."},{status:401});
  const body=await request.json().catch(()=>null); const errors=validateDraft(body);
  if(Object.keys(errors).length)return NextResponse.json({error:"Validation failed.",errors},{status:400});
  const {id}=await params; const application=await updateApplication(id,applicantId,body.type,body.answers);
  return application?NextResponse.json({application}):NextResponse.json({error:"Draft not found or is no longer editable."},{status:409});
}

export async function DELETE(request:Request,{params}:Context){
  const applicantId=await getApplicantId(request); if(!applicantId)return NextResponse.json({error:"Authentication required."},{status:401});
  const {id}=await params; const deleted=await deleteApplication(id,applicantId);
  return deleted?new Response(null,{status:204}):NextResponse.json({error:"Draft not found or is no longer editable."},{status:409});
}
