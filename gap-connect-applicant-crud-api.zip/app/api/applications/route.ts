import { NextResponse } from "next/server";
import { createApplication, listApplications } from "@/lib/application-store";
import { getApplicantId } from "@/lib/applicant-identity";
import { validateDraft } from "@/lib/application-rules.mjs";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const applicantId=await getApplicantId(request);
  if(!applicantId) return NextResponse.json({error:"Authentication required."},{status:401});
  return NextResponse.json({applications:await listApplications(applicantId)});
}

export async function POST(request: Request) {
  const applicantId=await getApplicantId(request);
  if(!applicantId) return NextResponse.json({error:"Authentication required."},{status:401});
  const body=await request.json().catch(()=>null); const errors=validateDraft(body);
  if(Object.keys(errors).length) return NextResponse.json({error:"Validation failed.",errors},{status:400});
  const application=await createApplication(applicantId,body.type,body.answers);
  return NextResponse.json({application},{status:201});
}
