import { index, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const applications = sqliteTable("applications", {
  id: text("id").primaryKey(),
  applicantId: text("applicant_id").notNull(),
  type: text("type", { enum: ["Foster", "Adopt"] }).notNull(),
  status: text("status", { enum: ["Draft", "Submitted"] }).notNull().default("Draft"),
  answersJson: text("answers_json").notNull().default("{}"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
  submittedAt: text("submitted_at"),
}, (table) => [
  index("idx_applications_applicant_updated").on(table.applicantId, table.updatedAt),
]);

export const applicationStatusHistory = sqliteTable("application_status_history", {
  id: text("id").primaryKey(),
  applicationId: text("application_id").notNull(),
  applicantId: text("applicant_id").notNull(),
  previousStatus: text("previous_status"),
  newStatus: text("new_status").notNull(),
  changedAt: text("changed_at").notNull(),
  comment: text("comment"),
}, (table) => [
  index("idx_application_history_application_time").on(table.applicationId, table.changedAt),
]);
