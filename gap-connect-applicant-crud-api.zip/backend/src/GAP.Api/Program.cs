using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    var key = builder.Configuration["JWT_SIGNING_KEY"] ?? throw new InvalidOperationException("JWT signing key is required");
    options.TokenValidationParameters = new TokenValidationParameters { ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true, ValidateIssuerSigningKey = true, ValidIssuer = "gap-api", ValidAudience = "gap-web", IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)) };
});
builder.Services.AddAuthorization(options => { options.AddPolicy("ApplicantOnly", p => p.RequireRole("Applicant")); options.AddPolicy("StaffOnly", p => p.RequireRole("Staff")); });
var app = builder.Build();
if (app.Environment.IsDevelopment()) { app.UseSwagger(); app.UseSwaggerUI(); }
app.UseHttpsRedirection(); app.UseAuthentication(); app.UseAuthorization(); app.MapControllers(); app.Run();

public partial class Program { }
