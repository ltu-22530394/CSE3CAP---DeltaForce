using GAP.Domain;
namespace GAP.Application;

public interface IEmailService { Task QueueAsync(string recipient, string template, object model, CancellationToken cancellationToken = default); }
public interface ICurrentUser { Guid UserId { get; } UserRole Role { get; } }
public interface IApplicationService {
    Task<Application> SaveDraftAsync(Guid? id, ApplicationType type, IReadOnlyDictionary<string,string> answers, CancellationToken ct);
    Task<Application> SubmitAsync(Guid id, CancellationToken ct);
    Task<Application> ChangeStatusAsync(Guid id, ApplicationStatus status, string? comment, CancellationToken ct);
    Task<GreyhoundAssignment> AssignGreyhoundAsync(Guid applicationId, Guid greyhoundId, CancellationToken ct);
}
public sealed record ImportError(int Row, string Field, string Message);
public sealed record ImportSummary(int TotalRows, int SuccessfulRows, int FailedRows, IReadOnlyList<ImportError> Errors);
public interface IGreyhoundCsvImporter { Task<ImportSummary> ImportAsync(Stream csv, CancellationToken ct); }
