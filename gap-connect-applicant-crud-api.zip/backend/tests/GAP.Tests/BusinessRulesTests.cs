using GAP.Domain;
using Xunit;
namespace GAP.Tests;

public class BusinessRulesTests {
    [Fact] public void New_application_starts_as_draft() { var app = new Application { ApplicantId = Guid.NewGuid(), Type = ApplicationType.Adopt }; Assert.Equal(ApplicationStatus.Draft, app.Status); }
    [Fact] public void Status_history_records_actor_and_time() { var h = new ApplicationStatusHistory { ApplicationId = Guid.NewGuid(), PreviousStatus = ApplicationStatus.Submitted, NewStatus = ApplicationStatus.UnderReview, ChangedByUserId = Guid.NewGuid() }; Assert.NotEqual(Guid.Empty, h.ChangedByUserId); Assert.True(h.ChangedAt <= DateTimeOffset.UtcNow); }
}
