import test from "node:test";
import assert from "node:assert/strict";
import { canEdit, validateDraft, validateSubmission } from "../lib/application-rules.mjs";

const completeAnswers={fullName:"Sophie Bennett",email:"sophie@example.com",phone:"0412 345 678",dateOfBirth:"1994-03-14",address:"18 Ocean Street",suburb:"Randwick",state:"NSW",postcode:"2031",residenceType:"House",ownership:"Own",adults:"2",children:"0",otherPets:"One cat",workArrangements:"Hybrid",hoursAway:"4-6",activityLevel:"Moderate",dogExperience:"Labrador owner",greyhoundExperience:"None",reason:"Permanent home",preferences:"Calm",exerciseRequirements:"Daily walk",accurate:true,privacyConsent:true,termsAccepted:true};

test("accepts a partial draft",()=>assert.deepEqual(validateDraft({type:"Adopt",answers:{fullName:"Sophie"}}),{}));
test("rejects an invalid application type",()=>assert.equal(validateDraft({type:"Unknown",answers:{}}).type,"Choose Foster or Adopt."));
test("accepts a complete submission",()=>assert.deepEqual(validateSubmission({type:"Adopt",answers:completeAnswers}),{}));
test("reports invalid contact and missing consent",()=>{const errors=validateSubmission({type:"Foster",answers:{...completeAnswers,email:"wrong",postcode:"20",termsAccepted:false}});assert.ok(errors.email);assert.ok(errors.postcode);assert.ok(errors.termsAccepted);});
test("only the owning applicant can edit a draft",()=>{assert.equal(canEdit({applicantId:"a",status:"Draft"},"a"),true);assert.equal(canEdit({applicantId:"a",status:"Submitted"},"a"),false);assert.equal(canEdit({applicantId:"a",status:"Draft"},"b"),false);});
