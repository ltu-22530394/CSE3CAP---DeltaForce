export type ApplicantApplication={id:string;type:"Foster"|"Adopt";status:"Draft"|"Submitted";answers:Record<string,unknown>;createdAt:string;updatedAt:string;submittedAt:string|null};
const headers={"content-type":"application/json","x-gap-demo-applicant":"sophie-bennett"};
async function parse(response:Response){const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(data.error||"Request failed.");return data;}
export async function listApplicantApplications():Promise<ApplicantApplication[]>{return (await parse(await fetch("/api/applications",{headers,cache:"no-store"}))).applications;}
export async function saveApplicantDraft(input:{id?:string;type:"Foster"|"Adopt";answers:Record<string,unknown>}):Promise<ApplicantApplication>{
 const response=await fetch(input.id?`/api/applications/${input.id}`:"/api/applications",{method:input.id?"PUT":"POST",headers,body:JSON.stringify({type:input.type,answers:input.answers})}); return (await parse(response)).application;
}
export async function submitApplicantDraft(id:string):Promise<ApplicantApplication>{return (await parse(await fetch(`/api/applications/${id}/submit`,{method:"POST",headers}))).application;}
