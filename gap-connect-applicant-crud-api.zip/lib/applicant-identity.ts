import { getChatGPTUser } from "@/app/chatgpt-auth";

export async function getApplicantId(request: Request) {
  const user = await getChatGPTUser();
  if (user?.userId) return `chatgpt:${user.userId}`;

  // Explicit demo identity keeps the public capstone prototype usable until
  // DEL-43 supplies the production applicant JWT contract.
  const demoId = request.headers.get("x-gap-demo-applicant");
  return demoId ? `demo:${demoId}` : null;
}
