import { env } from "cloudflare:workers";

type StoredApplication = {
  id: string; applicantId: string; type: "Foster" | "Adopt"; status: "Draft" | "Submitted";
  answers: Record<string, unknown>; createdAt: string; updatedAt: string; submittedAt: string | null;
};

async function ensureSchema() {
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS applications (
      id TEXT PRIMARY KEY, applicant_id TEXT NOT NULL, type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Draft', answers_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL, submitted_at TEXT
    )`),
    env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_applications_applicant_updated ON applications(applicant_id, updated_at)"),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS application_status_history (
      id TEXT PRIMARY KEY, application_id TEXT NOT NULL, applicant_id TEXT NOT NULL,
      previous_status TEXT, new_status TEXT NOT NULL, changed_at TEXT NOT NULL, comment TEXT
    )`),
    env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_application_history_application_time ON application_status_history(application_id, changed_at)"),
  ]);
}

function mapRow(row: Record<string, unknown>): StoredApplication {
  return { id:String(row.id), applicantId:String(row.applicant_id), type:row.type as "Foster"|"Adopt", status:row.status as "Draft"|"Submitted", answers:JSON.parse(String(row.answers_json || "{}")), createdAt:String(row.created_at), updatedAt:String(row.updated_at), submittedAt:row.submitted_at ? String(row.submitted_at) : null };
}

export async function listApplications(applicantId: string) {
  await ensureSchema();
  const result = await env.DB.prepare("SELECT * FROM applications WHERE applicant_id = ? ORDER BY updated_at DESC").bind(applicantId).all();
  return (result.results as Record<string, unknown>[]).map(mapRow);
}

export async function getApplication(id: string, applicantId: string) {
  await ensureSchema();
  const row = await env.DB.prepare("SELECT * FROM applications WHERE id = ? AND applicant_id = ?").bind(id, applicantId).first();
  return row ? mapRow(row as Record<string, unknown>) : null;
}

export async function createApplication(applicantId: string, type: "Foster"|"Adopt", answers: Record<string, unknown>) {
  await ensureSchema(); const now=new Date().toISOString(); const id=`APP-${crypto.randomUUID().slice(0,8).toUpperCase()}`;
  await env.DB.batch([
    env.DB.prepare("INSERT INTO applications (id, applicant_id, type, status, answers_json, created_at, updated_at) VALUES (?, ?, ?, 'Draft', ?, ?, ?)").bind(id,applicantId,type,JSON.stringify(answers),now,now),
    env.DB.prepare("INSERT INTO application_status_history (id, application_id, applicant_id, previous_status, new_status, changed_at, comment) VALUES (?, ?, ?, NULL, 'Draft', ?, 'Draft created')").bind(crypto.randomUUID(),id,applicantId,now),
  ]);
  return getApplication(id,applicantId);
}

export async function updateApplication(id:string, applicantId:string, type:"Foster"|"Adopt", answers:Record<string,unknown>) {
  await ensureSchema(); const now=new Date().toISOString();
  const result=await env.DB.prepare("UPDATE applications SET type=?, answers_json=?, updated_at=? WHERE id=? AND applicant_id=? AND status='Draft'").bind(type,JSON.stringify(answers),now,id,applicantId).run();
  return result.meta.changes ? getApplication(id,applicantId) : null;
}

export async function deleteApplication(id:string, applicantId:string) {
  await ensureSchema();
  const result=await env.DB.prepare("DELETE FROM applications WHERE id=? AND applicant_id=? AND status='Draft'").bind(id,applicantId).run();
  return result.meta.changes > 0;
}

export async function submitApplication(id:string, applicantId:string) {
  await ensureSchema(); const now=new Date().toISOString();
  const current=await getApplication(id,applicantId); if(!current || current.status!=="Draft") return null;
  await env.DB.batch([
    env.DB.prepare("UPDATE applications SET status='Submitted', submitted_at=?, updated_at=? WHERE id=? AND applicant_id=? AND status='Draft'").bind(now,now,id,applicantId),
    env.DB.prepare("INSERT INTO application_status_history (id, application_id, applicant_id, previous_status, new_status, changed_at, comment) VALUES (?, ?, ?, 'Draft', 'Submitted', ?, 'Application submitted')").bind(crypto.randomUUID(),id,applicantId,now),
  ]);
  return getApplication(id,applicantId);
}
